import time
import os
import sys

variables = {}

def run_ns(file_path):
    if not file_path.endswith('.ns'): return
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            lines = f.readlines()
        
        for line in lines:
            line = line.strip()
            if not line or line.startswith('note'): continue
            
            p = line.split(' ', 1)
            cmd = p[0]
            arg = p[1] if len(p) > 1 else ""

            if cmd == 'set':
                v = arg.split(' ', 1)
                name, val = v[0], v[1].strip('"')
                try:
                    variables[name] = float(val) if '.' in val else int(val)
                except:
                    variables[name] = val
            
            elif cmd == 'add':
                v = arg.split(' ', 1)
                target_var = v[0]
                value_to_add = v[1]
                # Kiểm tra nếu value_to_add là một biến đã tồn tại
                if value_to_add in variables:
                    variables[target_var] += variables[value_to_add]
                else:
                    variables[target_var] += float(value_to_add)

            elif cmd == 'sub':
                v = arg.split(' ', 1)
                target_var = v[0]
                value_to_sub = v[1]
                # Kiểm tra nếu value_to_sub là một biến đã tồn tại
                if value_to_sub in variables:
                    variables[target_var] -= variables[value_to_sub]
                else:
                    variables[target_var] -= float(value_to_sub)

            elif cmd == 'write':
                out = arg.strip('"')
                print(variables.get(out, out))
            elif cmd == 'input':
                raw = input()
                variables[arg] = float(raw) if '.' in raw else int(raw)
            elif cmd == 'input_str':
                variables[arg] = input()
            elif cmd == 'wait':
                time.sleep(float(arg))
            elif cmd == 'clear':
                os.system('cls' if os.name == 'nt' else 'clear')
            elif cmd == 'color':
                c_map = {"red":"4", "green":"2", "cyan":"3", "white":"7"}
                c_code = c_map.get(arg.strip('"'), "7")
                os.system('color 0' + c_code)
    except Exception as e:
        print(f"System Error: {e}")

if __name__ == "__main__":
    target = sys.argv[1] if len(sys.argv) > 1 else 'ide.ns'
    run_ns(target)