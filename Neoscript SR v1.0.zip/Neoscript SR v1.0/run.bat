@echo off
title NeoScript Stable Release v1.0
cls

echo ==========================================
echo    NEOSCRIPT STABLE RELEASE V1.0
echo    Core: Python Interpreter
echo    Status: Running...
echo ==========================================
echo.

python Neoscript_SR_v1.0.py ide.ns

echo.
echo ==========================================
echo    Execution Finished.
echo    Press any key to exit...
echo ==========================================
pause >nul